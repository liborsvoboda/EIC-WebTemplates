storage
========

An asynchronous database abstraction layer for YUI.

Status: WIP
